"""
Discord VPS Delivery Bot
No database and no JSON files.
All bot data is stored in plain-text files in this same folder.

Install:  python -m pip install -r requirements.txt
Run:      python bot.py

Paste your bot token and primary owner ID below.
"""

import ast
import discord
from discord import app_commands
from discord.ext import commands
from pathlib import Path

# ============================================================
# PASTE YOUR DETAILS HERE
# ============================================================
BOT_TOKEN = "PASTE YOUR BOT TOKEN HERE"
OWNER_ID = 123456789012345678  # PASTE YOUR NUMERIC DISCORD USER ID HERE

BASE = Path(__file__).resolve().parent
ADMINS_FILE = BASE / "admins.txt"
OWNERS_FILE = BASE / "owners.txt"
VPS_FILE = BASE / "vps.txt"


def read_data(path, default):
    if not path.exists():
        return default
    try:
        return ast.literal_eval(path.read_text(encoding="utf-8"))
    except (ValueError, SyntaxError, OSError):
        return default


def write_data(path, value):
    path.write_text(repr(value), encoding="utf-8")


def owner_ids():
    return {int(OWNER_ID)} | {int(x) for x in read_data(OWNERS_FILE, [])}


def admin_ids():
    return {int(x) for x in read_data(ADMINS_FILE, [])}


def is_owner(uid):
    return int(uid) in owner_ids()


def is_staff(uid):
    return is_owner(uid) or int(uid) in admin_ids()


intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)


async def require_staff(interaction):
    if not is_staff(interaction.user.id):
        await interaction.response.send_message(
            "You do not have permission to use this command.", ephemeral=True
        )
        return False
    return True


@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"Logged in as {bot.user}. Synced {len(synced)} slash commands.")
    except Exception as error:
        print(f"Slash-command sync error: {error}")
    print("Discord VPS Delivery Bot is online.")


@bot.tree.command(name="help", description="Show bot commands")
async def help_command(interaction: discord.Interaction):
    await interaction.response.send_message(
        "**VPS Delivery Bot**\n"
        "`/myvps` - View your assigned VPS details.\n"
        "`/sendmessage` - Staff: save and send VPS details to a user.\n"
        "`/listvps` - Staff: list users with assigned VPS details.\n"
        "`/addadmin` - Owner: add an admin.\n"
        "`/removeadmin` - Owner: remove an admin.\n"
        "`/adminlist` - Owner: list admins.\n"
        "`/addowner` - Owner: add another owner.\n"
        "`/removeowner` - Owner: remove an additional owner.\n"
        "`/ownerlist` - Owner: list owners.",
        ephemeral=True
    )


@bot.tree.command(name="myvps", description="Show the VPS details assigned to you")
async def myvps(interaction: discord.Interaction):
    records = read_data(VPS_FILE, {})
    details = records.get(str(interaction.user.id))
    if not details:
        await interaction.response.send_message(
            "No VPS details have been assigned to you yet. Please contact staff.",
            ephemeral=True
        )
        return
    await interaction.response.send_message(
        f"**Your VPS Details**\n{details}",
        ephemeral=True,
        allowed_mentions=discord.AllowedMentions.none()
    )


@bot.tree.command(name="sendmessage", description="Assign or update a user's VPS details")
@app_commands.describe(
    user="Discord user receiving the VPS details",
    message="VPS IP, username, password, OS, web URL, port and other details"
)
async def sendmessage(interaction: discord.Interaction, user: discord.User, message: str):
    if not await require_staff(interaction):
        return

    records = read_data(VPS_FILE, {})
    records[str(user.id)] = message
    write_data(VPS_FILE, records)

    sent = False
    try:
        await user.send(
            f"**Your VPS details have been provided.**\n\n{message}",
            allowed_mentions=discord.AllowedMentions.none()
        )
        sent = True
    except (discord.Forbidden, discord.HTTPException):
        pass

    result = "Saved and sent by DM." if sent else (
        "Saved. I could not send a DM, but the user can still use `/myvps`."
    )
    await interaction.response.send_message(
        f"{result} {user.mention} can use `/myvps` anytime.",
        ephemeral=True,
        allowed_mentions=discord.AllowedMentions.none()
    )


@bot.tree.command(name="listvps", description="List users with VPS details")
async def listvps(interaction: discord.Interaction):
    if not await require_staff(interaction):
        return
    records = read_data(VPS_FILE, {})
    if not records:
        await interaction.response.send_message("No VPS records yet.", ephemeral=True)
        return
    lines = [f"<@{uid}> (`{uid}`)" for uid in records]
    output = "**Users with VPS details**\n" + "\n".join(lines[:50])
    if len(lines) > 50:
        output += f"\n…and {len(lines) - 50} more."
    await interaction.response.send_message(
        output, ephemeral=True, allowed_mentions=discord.AllowedMentions.none()
    )


@bot.tree.command(name="addadmin", description="Owner: give a user staff access")
async def addadmin(interaction: discord.Interaction, user: discord.User):
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    ids = admin_ids()
    ids.add(user.id)
    write_data(ADMINS_FILE, sorted(ids))
    await interaction.response.send_message(
        f"{user.mention} is now an admin.", ephemeral=True
    )


@bot.tree.command(name="removeadmin", description="Owner: remove staff access")
async def removeadmin(interaction: discord.Interaction, user: discord.User):
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    ids = admin_ids()
    ids.discard(user.id)
    write_data(ADMINS_FILE, sorted(ids))
    await interaction.response.send_message("Admin access removed.", ephemeral=True)


@bot.tree.command(name="adminlist", description="Owner: show admins")
async def adminlist(interaction: discord.Interaction):
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    ids = sorted(admin_ids())
    result = "\n".join(f"`{uid}`" for uid in ids) if ids else "No admins."
    await interaction.response.send_message(f"**Admins**\n{result}", ephemeral=True)


@bot.tree.command(name="addowner", description="Owner: add another owner")
async def addowner(interaction: discord.Interaction, user: discord.User):
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    ids = owner_ids()
    ids.add(user.id)
    ids.discard(int(OWNER_ID))
    write_data(OWNERS_FILE, sorted(ids))
    await interaction.response.send_message(
        f"{user.mention} added as an additional owner.", ephemeral=True
    )


@bot.tree.command(name="removeowner", description="Owner: remove an additional owner")
async def removeowner(interaction: discord.Interaction, user: discord.User):
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    if user.id == int(OWNER_ID):
        await interaction.response.send_message(
            "The primary owner in bot.py cannot be removed.", ephemeral=True
        )
        return
    ids = owner_ids()
    ids.discard(user.id)
    write_data(OWNERS_FILE, sorted(ids))
    await interaction.response.send_message("Additional owner removed.", ephemeral=True)


@bot.tree.command(name="ownerlist", description="Owner: show owner IDs")
async def ownerlist(interaction: discord.Interaction):
    if not is_owner(interaction.user.id):
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    result = "\n".join(f"`{uid}`" for uid in sorted(owner_ids()))
    await interaction.response.send_message(f"**Owners**\n{result}", ephemeral=True)


if __name__ == "__main__":
    if BOT_TOKEN == "PASTE YOUR BOT TOKEN HERE" or not BOT_TOKEN.strip():
        raise SystemExit("Paste your Discord bot token into BOT_TOKEN in bot.py.")
    if not isinstance(OWNER_ID, int) or OWNER_ID <= 0:
        raise SystemExit("Set OWNER_ID to your numeric Discord user ID in bot.py.")
    bot.run(BOT_TOKEN)
