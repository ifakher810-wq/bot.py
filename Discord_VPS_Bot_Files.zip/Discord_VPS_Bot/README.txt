DISCORD VPS DELIVERY BOT
========================

FILES
- bot.py: main bot program. Paste BOT_TOKEN and OWNER_ID near the top.
- requirements.txt: Python package needed to run the bot.
- admins.txt, owners.txt, vps.txt: created automatically when needed.
  These are plain text files, not JSON and not a database.

INSTALL ON UBUNTU / DEBIAN
1. Install Python and pip:
   sudo apt update
   sudo apt install -y python3 python3-pip
2. Open this folder:
   cd Discord_VPS_Bot
3. Install the requirement:
   python3 -m pip install -r requirements.txt
4. Edit bot.py and paste your Discord bot token and numeric owner ID.
5. Start:
   python3 bot.py

COMMANDS
/help
/myvps
/sendmessage user message
/listvps
/addadmin user
/removeadmin user
/adminlist
/addowner user
/removeowner user
/ownerlist

HOW VPS DELIVERY WORKS
Staff runs /sendmessage, selects the Discord user, and enters the VPS
details. The bot saves those details and attempts to DM the user.
The user can run /myvps later to view the saved details.

IMPORTANT
- This bot does NOT create or deploy VPS machines.
- Keep bot.py private because it contains your bot token.
- Do not share VPS passwords in public channels. Prefer sending credentials
  through a private, secure method.
- Keep this whole folder backed up. The .txt files contain bot records.
